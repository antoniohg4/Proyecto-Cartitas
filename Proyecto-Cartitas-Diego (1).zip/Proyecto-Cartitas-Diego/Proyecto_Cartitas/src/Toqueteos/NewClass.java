/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Toqueteos;

/**
 *
 * @author DAM-2
 */
public class NewClass {
    public static void main(String[] args) {
        Toqueteos t = new Toqueteos();
        
    }
}
